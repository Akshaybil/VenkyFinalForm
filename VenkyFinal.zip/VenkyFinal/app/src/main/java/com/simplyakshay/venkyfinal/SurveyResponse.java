package com.simplyakshay.venkyfinal;

public class SurveyResponse {
    private String ClientName;
    private String QuesNo;
    private String Response;
    private String Timestamp;

    public SurveyResponse(String ClientName, String QuesNo, String Response){
        this.ClientName = ClientName;
        this.QuesNo = QuesNo;
        this.Response = Response;
//        this.Timestamp = Timestamp;
    }

    public String getClientName() {
        return this.ClientName;
    }

    public String getQuesNo() {
        return this.QuesNo;
    }

    public String getResponse() {
        return this.Response;
    }

    public void setClientName(String clientName){
        this.ClientName = clientName;
    }
    public void setQuesNo(String QuesNo){
        this.QuesNo = QuesNo;
    }
    public void setResponse(String Response){
        this.Response = Response;
    }
    public String getTimestamp() {
        return this.Timestamp;
    }
}
