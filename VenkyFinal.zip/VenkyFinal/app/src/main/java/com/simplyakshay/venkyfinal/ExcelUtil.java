package com.simplyakshay.venkyfinal;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExcelUtil {

    private static final String TAG = "Excel exporting";
    // creating the excel workbook
    // Global Variables
    private static Cell cell;
    private static Sheet sheet;
    private static Workbook workbook;
    private static CellStyle headerCellStyle;

    private static String EXCEL_SHEET_NAME = "Survey_Response";

    public static List<SurveyResponse> importedExcelData = new ArrayList<SurveyResponse>();

    public static boolean isCreated;

    public static boolean create_file(Context context, String fileName){

        // Check if available and not read only
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) {

            Log.e(TAG, "Storage not available or read only");
            return false;
        }
        // Creating a New HSSF Workbook (.xls format)
        workbook = new HSSFWorkbook();
        setHeaderRow();
        setHeaderCellStyle();

        // Creating a New Sheet and Setting width for each column

        sheet = workbook.createSheet(Constants.EXCEL_SHEET_NAME);
        sheet.setColumnWidth(0, (15 * 400));
        sheet.setColumnWidth(1, (15 * 400));
        sheet.setColumnWidth(2, (15 * 400));
        sheet.setColumnWidth(3, (15 * 400));

        isCreated = storeExcelInStorage(context, fileName);
        return isCreated;
    }

    public static void importExceldata(Context context, String fileName){

        File file = new File(context.getExternalFilesDir(null), fileName);
        FileInputStream fileInputStream = null;

        try {
            fileInputStream = new FileInputStream(file);
            Log.e(TAG, "Reading from Excel" + file);

            // Create instance having reference to .xls file
            workbook = new HSSFWorkbook(fileInputStream);

            // Fetch sheet at position 'i' from the workbook
            sheet = workbook.getSheetAt(0);
            List<String> rowDataList = new ArrayList<String>();
            // Iterate through each row
            for (Row row : sheet) {
                int index = 0;

                if (row.getRowNum() >= 0) {
                    // Iterate through all the columns in a row (Including header row)
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        // Check cell type and format accordingly
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_STRING:
                                Log.e(TAG, "Reading from Excel Iterator" + cell.getStringCellValue());
                                //todo inga dan importing logic
                                rowDataList.add(index,cell.getStringCellValue());
                                index++;

                                break;
                        }
                    }
                }
//                importedExcelData.add(rowDataList);
            }

            for(int i =0;i<=rowDataList.size();i++){
                importedExcelData.get(i).setClientName(rowDataList.get(i));
                importedExcelData.get(i).setQuesNo(rowDataList.get(i));
                importedExcelData.get(i).setResponse(rowDataList.get(i));
            }

        }catch (IOException e) {
            Log.e(TAG, "Error Reading Exception: ", e);

        } catch (Exception e) {
            Log.e(TAG, "Failed to read file due to Exception: ", e);

        } finally {
            try {
                if (null != fileInputStream) {
                    fileInputStream.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public static boolean exportDataIntoWorkbook(Context context, String fileName,
                                                 List<SurveyResponse> dataList) {
        boolean isWorkbookWrittenIntoStorage;

        // Check if available and not read only
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) {

            Log.e(TAG, "Storage not available or read only");
            return false;
        }

        // Creating a New HSSF Workbook (.xls format)
        workbook = new HSSFWorkbook();

        // Creating a New Sheet and Setting width for each column

        sheet = workbook.createSheet(Constants.EXCEL_SHEET_NAME);
        sheet.setColumnWidth(0, (15 * 400));
        sheet.setColumnWidth(1, (15 * 400));
        sheet.setColumnWidth(2, (15 * 400));
        sheet.setColumnWidth(3, (15 * 400));

        setHeaderRow();
//        setHeaderCellStyle();
        fillDataIntoExcel(dataList);
        isWorkbookWrittenIntoStorage = storeExcelInStorage(context, fileName);
        Log.e("DatasizeofImportExport", String.valueOf(ExcelUtil.importedExcelData.size()));
        return isWorkbookWrittenIntoStorage;


    }
    private static void fillDataIntoExcel(List<SurveyResponse> dataList) {
        for (int i = 0; i < dataList.size(); i++) {
            // Create a New Row for every new entry in list
            Row rowData = sheet.createRow(i + 1);

            // Create Cells for each row
            cell = rowData.createCell(0);
            cell.setCellValue(dataList.get(i).getClientName());

            cell = rowData.createCell(1);
            cell.setCellValue(dataList.get(i).getQuesNo());

            cell = rowData.createCell(2);
            cell.setCellValue(dataList.get(i).getResponse());

//            cell = rowData.createCell(4);
//            cell.setCellValue(dataList.get(i).getTimestamp());
        }
    }
    /**
     * Checks if Storage is READ-ONLY
     *
     * @return boolean
     */
    private static boolean isExternalStorageReadOnly() {
        String externalStorageState = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED_READ_ONLY.equals(externalStorageState);
    }

    /**
     * Checks if Storage is Available
     *
     * @return boolean
     */
    private static boolean isExternalStorageAvailable() {
        String externalStorageState = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(externalStorageState);
    }
    /**
     * Setup header cell style
     */
    private static void setHeaderCellStyle() {
        headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(HSSFColor.AQUA.index);
        headerCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        headerCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
    }

    /**
     * Setup Header Row
     */
    private static void setHeaderRow() {
        Row headerRow = sheet.createRow(0);

        cell = headerRow.createCell(0);
        cell.setCellValue("Client Name");
//        cell.setCellStyle(cellStyle);

        cell = headerRow.createCell(1);
        cell.setCellValue("Ques.No");
//        cell.setCellStyle(cellStyle);

        cell = headerRow.createCell(2);
        cell.setCellValue("Response");
//        cell.setCellStyle(cellStyle);

//        cell = headerRow.createCell(3);
//        cell.setCellValue("Timestamp");
    }
    /**
     * Store Excel Workbook in external storage
     *
     * @param context  - application context
     * @param fileName - name of workbook which will be stored in device
     * @return boolean - returns state whether workbook is written into storage or not
     */
    private static boolean storeExcelInStorage(Context context, String fileName) {
        boolean isSuccess;
        File file = new File(context.getExternalFilesDir(null), fileName);
        FileOutputStream fileOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream(file);
            workbook.write(fileOutputStream);
            Log.e(TAG, "Writing file" + file);
            isSuccess = true;
        } catch (IOException e) {
            Log.e(TAG, "Error writing Exception: ", e);
            isSuccess = false;
        } catch (Exception e) {
            Log.e(TAG, "Failed to save file due to Exception: ", e);
            isSuccess = false;
        } finally {
            try {
                if (null != fileOutputStream) {
                    fileOutputStream.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return isSuccess;
    }
}
