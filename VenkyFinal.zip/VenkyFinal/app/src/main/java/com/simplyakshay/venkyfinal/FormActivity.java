package com.simplyakshay.venkyfinal;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FormActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_WRITE_EXTERNAL_STORAGE = 1;

    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;

    SharedPreferences sharedpreferences;

    //logic for the ui and survey forms
    TextView st1,st3,st4,st7,st9; //textview of switch text result for Yes and No
    TextView t2,t5,t6,t8;  //textview of questions

    Switch s1,s3,s4,s7,s9;
    RatingBar r2, r5, r6, r8;

    Button submit;
    EditText clientNameE;
    //Answers
    public String ans1,ans2,ans3,ans4,ans5,ans6,ans7,ans8,ans9,ans10,ans11,ans12;

    //Survey Response in List
    public List<SurveyResponse> sur_ans = new ArrayList<SurveyResponse>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_form);

        // Permission for first time logic
        Boolean isFirstRun = getSharedPreferences("PREFERENCE", MODE_PRIVATE)
                .getBoolean("isFirstRun", true);
        sharedpreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        if (isFirstRun) {
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putBoolean("First", isFirstRun);
            editor.commit();

            if (ContextCompat.checkSelfPermission(FormActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(FormActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);


            if (ContextCompat.checkSelfPermission(FormActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {

                // Permission is not granted
                // Should we show an explanation?
                if (ActivityCompat.shouldShowRequestPermissionRationale(FormActivity.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    // Show an explanation to the user *asynchronously* -- don't block
                    // this thread waiting for the user's response! After the user
                    // sees the explanation, try again to request the permission.
                } else {
                    // No explanation needed; request the permission
                    ActivityCompat.requestPermissions(FormActivity.this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MY_PERMISSIONS_WRITE_EXTERNAL_STORAGE);
//                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                }
            }
            // todo create excel for first time
//            if (ExcelUtil.create_file(getApplicationContext(), Constants.EXCEL_FILE_NAME)) {
//                Toast.makeText(getApplicationContext(), "file created", Toast.LENGTH_LONG);
//            } else{
//                    Toast.makeText(getApplicationContext(), "file Not created", Toast.LENGTH_LONG);
//                }
        }
        // todo get the data everytime
//        ExcelUtil.importExceldata(getApplicationContext(),Constants.EXCEL_FILE_NAME);
        Log.e("DatasizeofImport1", String.valueOf(ExcelUtil.importedExcelData.size()));

        //Edit text to get client name
        clientNameE = (EditText) findViewById(R.id.clientName);
        // Switch
        s1 = (Switch) findViewById(R.id.switch1); // question1
        s3 = (Switch) findViewById(R.id.switch3); // question3
        s4 = (Switch) findViewById(R.id.switch4); // question4
        s7 = (Switch) findViewById(R.id.switch7); // question7
        s9 = (Switch) findViewById(R.id.switch9); // question9

        //TextView
        st1 = (TextView) findViewById(R.id.switchtxt1);

        //Items for question no 2
        t2 = (TextView) findViewById(R.id.txt2);
        r2 = (RatingBar) findViewById(R.id.ratingBar2);

        // Items for Question 3
        LinearLayout l3 = (LinearLayout) findViewById(R.id.layout3);
        st3 = (TextView) findViewById(R.id.switchtxt3);

        // Items for Question 4
        LinearLayout l4 = (LinearLayout) findViewById(R.id.layout4);
        st4 = (TextView) findViewById(R.id.switchtxt4);

        // Items for Question 5
        t5 = (TextView) findViewById(R.id.txt5);
        r5 = (RatingBar) findViewById(R.id.ratingBar5);

        //Items for Question 6
        t6 = (TextView) findViewById(R.id.txt6);
        r6 = (RatingBar) findViewById(R.id.ratingBar6);

        //Items for Question 7
        LinearLayout l7 = (LinearLayout) findViewById(R.id.layout7);
        st7 = (TextView) findViewById(R.id.switchtxt7);

        //Items for Question 8
        t8 = (TextView) findViewById(R.id.txt8);
        r8 = (RatingBar) findViewById(R.id.ratingBar8);

        //Items for Question 9
        LinearLayout l9 = (LinearLayout) findViewById(R.id.layout9);
        st9 = (TextView) findViewById(R.id.switchtxt9);

        //Rating Bar r2, r5, r6, r8
        LayerDrawable stars2 = (LayerDrawable) r2.getProgressDrawable();
        stars2.getDrawable(2).setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_ATOP);
        stars2.getDrawable(0).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        stars2.getDrawable(1).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);

        LayerDrawable stars5 = (LayerDrawable) r5.getProgressDrawable();
        stars5.getDrawable(2).setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_ATOP);
        stars5.getDrawable(0).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        stars5.getDrawable(1).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);

        LayerDrawable stars6 = (LayerDrawable) r6.getProgressDrawable();
        stars6.getDrawable(2).setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_ATOP);
        stars6.getDrawable(0).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        stars6.getDrawable(1).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);

        LayerDrawable stars8 = (LayerDrawable) r8.getProgressDrawable();
        stars8.getDrawable(2).setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_ATOP);
        stars8.getDrawable(0).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        stars8.getDrawable(1).setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
        //submit
        submit = (Button) findViewById(R.id.submit);

        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    st1.setText("Yes");
                    t2.setVisibility(View.VISIBLE);
                    r2.setVisibility(View.VISIBLE);
                }else{
                    st1.setText("No");
                }
            }
        });

        //Question2

        r2.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            // Called when the user swipes the RatingBar
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //make Question 3 visible

                l3.setVisibility(View.VISIBLE);
            }
        });

        //to make Question 4 visible
        s3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    st3.setText("Yes");
                    l4.setVisibility(View.VISIBLE);
                }else{
                    st3.setText("No");
//                    l4.setVisibility(View.VISIBLE);
                }
            }
        });

        //to make Question 5 visible
        s4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    st4.setText("Yes");
                    t5.setVisibility(View.VISIBLE);
                    r5.setVisibility(View.VISIBLE);

                }else{
                    st4.setText("No");
                    t5.setVisibility(View.VISIBLE);
                    r5.setVisibility(View.VISIBLE);
                }
            }
        });

        //to make Question 6 visible

        r5.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            // Called when the user swipes the RatingBar
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //make Question 6 visible

                t6.setVisibility(View.VISIBLE);
                r6.setVisibility(View.VISIBLE);
            }
        });

        //to make Question 7 visible

        r6.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            // Called when the user swipes the RatingBar
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //make Question 7 visible

                l7.setVisibility(View.VISIBLE);
            }
        });

        //to make Question 8 visible
        s7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    st7.setText("Yes");
                    t8.setVisibility(View.VISIBLE);
                    r8.setVisibility(View.VISIBLE);
                }else{
                    st7.setText("No");
                    t8.setVisibility(View.VISIBLE);
                    r8.setVisibility(View.VISIBLE);
                }
            }
        });

        //to make Question 9 visible

        r8.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            // Called when the user swipes the RatingBar
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //make Question 9 visible

                l9.setVisibility(View.VISIBLE);
            }
        });

        //to make Submit button visible
        s9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    st9.setText("Yes");
                    submit.setVisibility(View.VISIBLE);
                }else{
                    st9.setText("No");
                    submit.setVisibility(View.VISIBLE);
                }
            }
        });

        //To submit the answer
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans1 = (String) st1.getText();
                ans2 = String.valueOf(r2.getRating());
                ans3 = (String) st3.getText();
                ans4 = (String) st4.getText();
                ans5 = String.valueOf(r5.getRating());
                ans6 = String.valueOf(r6.getRating());
                ans7 = (String) st7.getText();
                ans8 = String.valueOf(r8.getRating());
                ans9 = (String) st9.getText();

                //generating the Survey response List
                generate_dataList();

                //todo main matter exporting to excel
                // idhula current form data vaa append pana paru
//                boolean isExcelGenerated = ExcelUtil.exportDataIntoWorkbook(getApplication(),
//                        Constants.EXCEL_FILE_NAME+".xls", ExcelUtil.importedExcelData);
                boolean isExcelGenerated = ExcelUtil.exportDataIntoWorkbook(getApplication(),
                        clientNameE.getText()+".xls", ExcelUtil.importedExcelData);

                if (isExcelGenerated) {
                    Toast.makeText(getApplicationContext(),
                                    "Data saved",
                                    Toast.LENGTH_LONG)
                            .show();
                    Log.e("file", String.valueOf(ExcelUtil.importedExcelData.get(0)));
                } else {
                    Toast.makeText(getApplicationContext(),
                                    "Error occurred",
                                    Toast.LENGTH_LONG)
                            .show();
                }
            }
        });

    }

    private void generate_dataList() {

        SurveyResponse sr1 = new SurveyResponse("Demo1","1",ans1);
        SurveyResponse sr2 = new SurveyResponse("Demo1","2",ans2);
        SurveyResponse sr3 = new SurveyResponse("Demo1","3",ans3);
        SurveyResponse sr4 = new SurveyResponse("Demo1","4",ans4);
        SurveyResponse sr5 = new SurveyResponse("Demo1","5",ans5);
        SurveyResponse sr6 = new SurveyResponse("Demo1","6",ans6);
        SurveyResponse sr7 = new SurveyResponse("Demo1","7",ans7);
        SurveyResponse sr8 = new SurveyResponse("Demo1","8",ans8);
        SurveyResponse sr9 = new SurveyResponse("Demo1","9",ans9);

        ExcelUtil.importedExcelData.add(sr1);
        ExcelUtil.importedExcelData.add(sr2);
        ExcelUtil.importedExcelData.add(sr3);
        ExcelUtil.importedExcelData.add(sr4);
        ExcelUtil.importedExcelData.add(sr5);
        ExcelUtil.importedExcelData.add(sr6);
        ExcelUtil.importedExcelData.add(sr7);
        ExcelUtil.importedExcelData.add(sr8);
        ExcelUtil.importedExcelData.add(sr9);
    }
}
